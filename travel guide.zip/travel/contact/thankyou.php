<html>
<head>
  <style type="text/css">
    .body{
    	background-color: grey;
    }

  </style>
</head>
<body>
</body>
</html>