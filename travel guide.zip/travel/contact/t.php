<html>
<head>
  <style type="text/css">
    .body{

    	background-color: grey;
    }

  </style>
</head>
<body style="background-color:#616161">
<h1 style= "color:#FFFFFF">Thank you for connecting with us</h1>

<p style= "color:#FFFFFF">We will get back to you soon</p>
</body>
</html>