
<html>
 
 <head>
    <title>Trip Advisor</title>

     <style type="text/css">
      .title1{
        background-color: grey;
        width:220px;
        height:70px;
        margin-top: 10px;
        margin-left: 600px;
        margin-bottom: 10px;
        border:5px black solid;
        text-align: center;
        text-shadow: 3px 2px white;
      } 
      .title2{
        background-color: lightblue;
        font-style: italic;
        text-align: center;
        width:720px;
        height:70px;
        margin-top: 10px;
        margin-left: 300px;
        margin-bottom: 10px;
        text-shadow: 3px 2px white;
        border:5px black solid;
      }   

      .main{
        background-color: brown;
        font-style: italic;
        text-align: center;
        width:400px;
        height:200px;
        margin-top: 100px;
        margin-left: 500px;
        margin-bottom: 10px;

        border:5px black solid;
      }   


      body {

         background-image: url('1.jpg');
     }


      </style>

     
  
             
   </head>
 <body>
   <div class="title1">
     <h1>Trip Advisor</h1>
   </div>

   <div class="title2">   
    <h2>Travel the world with our help</h2>
  </div>
   
  

  


   </body>
</html>