<!DOCTYPE html> 
<html> 
<body> 

<video width="400" controls>
  <source src="movie.mp4" type="video/mp4">
  
  Your browser does not support HTML5 video.
</video>

<p>
Video courtesy of 
<a href="https://www.bigbuckbunny.org/" target="_blank">Big Buck Bunny</a>.
</p>

</body> 
</html>
