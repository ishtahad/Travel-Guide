<html>
<head>
    <title>Travel Assistant</title>
	<link rel="icon" type= "image/png" href="head.png"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<style type="text/css">
		s10{
		    font-size:100px;
			
		}
		s20{
		    font-size:70px;
			
		}
		.welcome{margin-top:40px;text-align:right;margin-right:30px;}
		.pad{padding-top:40px;text-align:right;margin-right:90px;}
		.padleft1{margin-right:110px;}
		.padleft2{margin-right:100px;}
		.padleft3{margin-right:107px;}
		.padleft4{margin-right:35px;}
		.padleft5{margin-right:123px;}
		
	</style>
</head>

<body style="background:url(admin.jpg) no-repeat; background-size:100%">



   
   

   <br><br>
<div class="pad">
				
			
   <form action="includes/delet.inc.php" method="POST">
      <div class="padleft1">
				<h4 style= "color:#FFFFFF"> Which ID </h4>
			</div>
		<div class="padleft4">	
			<input type="text" style="height:30px" name="sku" value="">
		</div>
		
			
			 
			<br><br><br>
			<div class="padleft5">
				<button type="submit">delete</button>
			</div>

			<?php

			?>
    </form>  

  </div>


</body>

</html>
