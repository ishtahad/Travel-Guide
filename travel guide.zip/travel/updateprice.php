<html>
<head>
    <title>Travel Assistant</title>
	<link rel="icon" type= "image/png" href="head.png"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<style type="text/css">
		s10{
		    font-size:100px;
			
		}
		s20{
		    font-size:70px;
			
		}
		.welcome{margin-top:40px;text-align:right;margin-right:30px;}
		.pad{padding-top:40px;text-align:right;margin-right:90px;}
		.padleft1{margin-right:100px;margin-top:40px;}
		.padleft2{margin-right:100px;}
		.padleft3{margin-right:107px;}
		.padleft4{margin-right:48px;}
		.padleft5{margin-right:113px;}
		
	</style>
  
         <form action="includes/updatep.inc.php" method="POST">
      <div class="padleft1">
				<h4 style= "color:#FFFFFF"> ID </h4>
			</div>
			
			<input type="text" name="sku" value="">

			<div class="padleft1">
				<h4 style= "color:#FFFFFF"> New Price </h4>
			</div>
			
			<input type="text" name="price" value="">
		
		
			
			 
			<br><br><br>
			<div class="padleft5">
				<button type="submit">update</button>
			</div>
    </form>  

</head>

<body style="background:url(admin.jpg) no-repeat; background-size:100%">



   
   

   <br><br>
<div class="pad">
				
			
   <form  method="POST">
      
			
			
		
		
			
			 
			

			
    </form>  

  </div>


</body>

</html>
